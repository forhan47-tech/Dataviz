# ================================
# Basic Script: Assignment & Comments
# ================================

# 1.2.1 Assignment
x <- 10
y <- 5
z <- x + y

# Print results
print(x)
print(y)
print(z)

# Multiple assignment
a <- b <- 100
paste("a =", a, "b =", b)